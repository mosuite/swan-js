/**
 * @file splitApp功能全局状态对象
 * @author haoran@baidu.com
 */

export default {
    allJsLoaded: true,
    tabBarList: [],
    routeResolve: () => {}
};
